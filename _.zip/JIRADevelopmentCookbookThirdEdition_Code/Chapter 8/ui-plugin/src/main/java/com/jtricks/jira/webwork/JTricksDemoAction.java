package com.jtricks.jira.webwork;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.atlassian.jira.web.action.JiraWebActionSupport;

public class JTricksDemoAction extends JiraWebActionSupport
{
    private static final Logger log = LoggerFactory.getLogger(JTricksDemoAction.class);

    @Override
    public String doDefault() throws Exception {
    	return super.doDefault();
    }
}

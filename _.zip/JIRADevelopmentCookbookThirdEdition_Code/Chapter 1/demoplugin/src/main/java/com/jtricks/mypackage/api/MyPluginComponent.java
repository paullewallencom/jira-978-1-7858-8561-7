package com.jtricks.mypackage.api;

public interface MyPluginComponent
{
    String getName();
}
package com.jtricks.utilities;

public class NumberUtility {

	public static int add(int x, int y) {
		return x + y;
	}
	
}

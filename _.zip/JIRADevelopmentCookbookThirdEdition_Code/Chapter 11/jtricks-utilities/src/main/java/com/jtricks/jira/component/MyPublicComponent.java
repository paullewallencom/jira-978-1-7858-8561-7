package com.jtricks.jira.component;

public interface MyPublicComponent {

	public void doSomething();

}

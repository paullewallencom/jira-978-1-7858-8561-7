package com.jtricks.jira.component;

public interface MyPrivateComponent {

	public void doSomething();

}

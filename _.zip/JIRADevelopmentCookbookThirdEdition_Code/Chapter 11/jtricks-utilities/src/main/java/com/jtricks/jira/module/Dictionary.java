package com.jtricks.jira.module;

public interface Dictionary {
	String getDefinition(String text);
}
